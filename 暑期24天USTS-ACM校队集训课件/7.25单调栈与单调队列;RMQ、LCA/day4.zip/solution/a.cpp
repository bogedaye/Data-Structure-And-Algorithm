#include<bits/stdc++.h>
#define pa pair<int,int>
#define ll long long
using namespace std;
const int maxn=100010,maxk=110;

inline ll rd(){
    ll x=0;char c=getchar();int neg=1;
    while(c<'0'||c>'9'){if(c=='-') neg=-1;c=getchar();}
    while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
    return x*neg;
}

struct POS{
    int l,r;
}pos[maxn],p[maxn];
int N,K;
int f[maxn][maxk];
int que[maxn][maxk],qh[maxn],qt[maxn],ma[maxn];

inline bool cmp(POS a,POS b){
    return a.l==b.l?a.r>b.r:a.l<b.l;
}

int main(){
    int i,j,k;
    //freopen("testdata.in","r",stdin);
    N=rd(),K=rd();
    for(i=1;i<=N;i++){
        pos[i].l=rd(),pos[i].r=rd();
    }sort(pos+1,pos+N+1,cmp);
    int mm=0;
    for(i=1,j=0;i<=N;i++){
        if(mm<pos[i].r) p[++j]=pos[i],mm=pos[i].r;
    }K-=N-j;N=j;
    if(K<=0){
        int ans=0;
        for(i=1;i<=N;i++){
            ans+=max(0,p[i].r-max(p[i-1].r,p[i].l));
        }printf("%d\n",ans);
    }else{
        p[N+1].l=1e9,p[N+1].r=1e9;N++;
        for(i=1;i<=N;i++){
            for(j=0;j<=min(i-1,K);j++){
                int ii=i-j-1;
                while(qh[ii]<qt[ii]&&p[que[ii][qh[ii]]].r<=p[i].l){
                    ma[ii]=max(ma[ii],f[que[ii][qh[ii]]][que[ii][qh[ii]]-ii]);qh[ii]++;
                }int hh=que[ii][qh[ii]];
                f[i][j]=max(ma[ii]+p[i].r-p[i].l,f[hh][hh-ii]+p[i].r-max(p[hh].r,p[i].l));
                ii=i-j;int qq=que[ii][qt[ii]];
                while(qh[ii]<qt[ii]&&f[qq][qq-ii]-p[qq].r<=f[i][j]-p[i].r){
                    qt[ii]--;qq=que[ii][qt[ii]];
                }que[ii][++qt[ii]]=i;if(!qh[ii]) qh[ii]++;
            }
        }
        printf("%d\n",f[N][K]);
    }
    return 0;
}
