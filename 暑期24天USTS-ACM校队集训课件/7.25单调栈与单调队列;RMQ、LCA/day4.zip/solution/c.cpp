#include"bits/stdc++.h"


#define PB push_back
#define PF push_front
#define LB lower_bound
#define UB upper_bound
#define fr(x) freopen(x,"r",stdin)
#define fw(x) freopen(x,"w",stdout)
#define iout(x) printf("%d\n",x)
#define lout(x) printf("%lld\n",x)
#define REP(x,l,u) for(int x = (l);x<=(u);x++)
#define RREP(x,l,u) for(int x = (l);x>=(u);x--)
#define mst(x,a) memset(x,a,sizeof(x))
#define PII pair<int,int>
#define PLL pair<ll,ll>
#define MP make_pair
#define se second
#define fi first
#define dbg(x) cout<<#x<<" = "<<(x)<<endl;
#define sz(x) ((int)x.size())
#define cl(x) x.clear()

typedef  long long ll;
typedef unsigned long long ull;
typedef double db;
typedef long double ld;
using namespace std;

const int maxn = 200010;
const int mod = 1e9+7;
const int MAX = 1000000010;
const double eps = 1e-6;
const double PI = acos(-1);

template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}
template<typename A,typename B> inline A fexp(A x,B p){A ans=1;for(;p;p>>=1,x=1LL*x*x%mod)if(p&1)ans=1LL*ans*x%mod;return ans;}
template<typename A,typename B> inline A fexp(A x,B p,A mo){A ans=1;for(;p;p>>=1,x=1LL*x*x%mo)if(p&1)ans=1LL*ans*x%mo;return ans;}

int n,m;

vector<int> G[maxn];

int dep[maxn],fa[maxn],son[maxn],size[maxn],an[maxn],l[maxn],r[maxn],pos[maxn],dfn;

void dfs1(int u,int f){
	dep[u]=dep[f]+1;
	size[u]=1;
	fa[u]=f;
	for(auto v:G[u])if(v!=f)dfs1(v,u),size[u]+=size[v];
	if(size[u]>size[son[fa[u]]])son[fa[u]]=u;
}

void dfs2(int u,int anc){
	l[u]=++dfn;pos[dfn]=u;
	an[u]=anc;
	if(son[u])dfs2(son[u],anc);
	for(auto v:G[u])if(v!=fa[u]&&v!=son[u])dfs2(v,v);
	r[u]=dfn;
}

int lca(int u,int v){
	while(an[u]!=an[v]){
		if(dep[an[u]]>dep[an[v]])swap(u,v);
		v=fa[an[v]];
	}
	return dep[u]<dep[v]?u:v;
}

int dis(int u,int v){
	int p=lca(u,v);
	return dep[u]+dep[v]-2*dep[p];
}

int getup(int u,int d){
	d=dep[u]-d;
	while(dep[an[u]]>d)u=fa[an[u]];
	return pos[l[u]-(dep[u]-d)];
}

struct Dia{
	int u,v;
	Dia(int u=0,int v=0):u(u),v(v) {}
}Td[maxn],pre[maxn],suf[maxn];

Dia operator+(const Dia &a,const Dia &b){
	if(!a.u)return b;if(!b.u)return a;
	int A[4];
	A[0]=a.u;A[1]=a.v;A[2]=b.u;A[3]=b.v;
	Dia ans=a;int d=0;
	REP(i,0,3)
		REP(j,i+1,3){
			int t=dis(A[i],A[j]);
			if(t>d){
				d=t;ans=Dia(A[i],A[j]);
			}
		}
	return ans;
}

void dfs3(int u){
	Td[u]=Dia(u,u);
	for(auto v:G[u])if(v!=fa[u]){
		dfs3(v);
		Td[u]=Td[u]+Td[v];
	}
}

bool check(int u,int goA,int v,int goB){
	int d=dis(u,v);
	if(goA>=d)return 0;
	int p=lca(u,v);
	if(goA<dep[u]-dep[p]){
		int now=getup(u,goA);
		Dia t=pre[l[now]-1]+suf[r[now]+1];
//		if(max(dis(v,t.u),dis(v,t.v))>=goB)cerr<<"!!!!\n";else cerr<<"????\n";
		return max(dis(v,t.u),dis(v,t.v))>=goB;
	}
	int now=getup(v,d-goA-1);
//	if(max(dis(v,Td[now].u),dis(v,Td[now].v))>=goB)cerr<<"!!!!\n";else cerr<<"????\n";
	return max(dis(v,Td[now].u),dis(v,Td[now].v))>=goB;
}

void Work(){
	while(m--){
		int a,b,k;read(a,b,k);
		int d=dis(a,b);
		if(d>k){
			printf("%d\n",k&1);
			continue;
		}
		if(k&1){
			if(d&1){
				if(check(a,k/2+1,b,k/2))printf("1\n");else printf("2\n");
			}
			else{
				printf("1\n");
			}
		}
		else{
			if(d&1){
				printf("0\n");
			}
			else{
				if(check(b,k/2,a,k/2))printf("0\n");else printf("-1\n");
			}
		}
	}
}

void Init(){
	read(n,m);
	REP(i,2,n){
		int u,v;read(u,v);
		G[u].PB(v);G[v].PB(u);
	}
	dfs1(1,0);
	dfs2(1,1);
	dfs3(1);
	REP(i,1,n)pre[i]=pre[i-1]+Dia(pos[i],pos[i]);
	RREP(i,n,1)suf[i]=suf[i+1]+Dia(pos[i],pos[i]);
}

int main(){
//	fr("b.in");fw("b.out");
	Init();
	Work();
	return 0;
}

