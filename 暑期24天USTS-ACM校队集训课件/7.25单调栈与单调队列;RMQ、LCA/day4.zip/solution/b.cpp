#include<bits/stdc++.h>

using namespace std;
#define N 300005
int n,m,i,j,k;
int a[N],b[N],l[N],r[N];
int st[N];
int top;
long long s[N];
long long tmp,ans;
int main()
{
    int T;
    T=1;
    while(T--)
    {
        scanf("%d",&n);
        for(i=1;i<=n;i++)
            scanf("%d",&a[i]);
        ans=s[0]=b[0]=0;
        for(k=1;k<=n;k++)
        {
            m=n/k;
            for(i=1;i<=m;i++)
                b[i]=a[i*k];
            b[m+1]=0;
            st[top=1]=0;
            for(i=1;i<=m;i++)
            {
                while(b[i]<=b[st[top]])
                    top--;
                l[i]=st[top];st[++top]=i;
            }
            st[top=1]=m+1;
            for(i=m;i;i--)
            {
                while(b[i]<=b[st[top]]) top--;
                r[i]=st[top];st[++top]=i;
            }
            for(i=1;i<=m;i++) s[i]=s[i-1]+b[i];
            for(i=1;i<=m;i++)
            {
                tmp=(s[r[i]-1]-s[l[i]])*b[i]*int(sqrt(k));
                if(tmp>ans) ans=tmp;
            }
        }
        cout<<ans<<endl;
    }
}
