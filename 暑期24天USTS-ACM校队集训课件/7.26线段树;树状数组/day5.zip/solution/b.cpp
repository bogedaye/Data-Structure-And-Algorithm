#include"bits/stdc++.h"


#define PB push_back
#define PF push_front
#define LB lower_bound
#define UB upper_bound
#define fr(x) freopen(x,"r",stdin)
#define fw(x) freopen(x,"w",stdout)
#define iout(x) printf("%d\n",x)
#define lout(x) printf("%lld\n",x)
#define REP(x,l,u) for(int x = (l);x<=(u);x++)
#define RREP(x,l,u) for(int x = (l);x>=(u);x--)
#define mst(x,a) memset(x,a,sizeof(x))
#define PII pair<int,int>
#define PLL pair<ll,ll>
#define MP make_pair
#define se second
#define fi first
#define dbg(x) cout<<#x<<" = "<<(x)<<endl;
#define sz(x) ((int)x.size())

typedef  long long ll;
typedef unsigned long long ull;
typedef double db;
typedef long double ld;
using namespace std;

const int maxn = 2000010;
const int mod = 1e9+7;
const double eps = 1e-6;
const double PI = acos(-1);

template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}
template<typename A,typename B> inline A fexp(A x,B p){A ans=1;for(;p;p>>=1,x=1LL*x*x%mod)if(p&1)ans=1LL*ans*x%mod;return ans;}
template<typename A,typename B> inline A fexp(A x,B p,A mo){A ans=1;for(;p;p>>=1,x=1LL*x*x%mo)if(p&1)ans=1LL*ans*x%mo;return ans;}

int n,cnt,tot;

int A[maxn],B[maxn<<1],c1[maxn],c2[maxn],opt[maxn],pos[maxn],rk[maxn],L[maxn],R[maxn];

void add1(int x,int y){
	for(;x<=cnt;x+=x&-x)c1[x]+=y;
}

void add2(int x,int y){
	for(;x<=cnt;x+=x&-x)c2[x]+=y;
}

int query1(int x){
	int ans=0;
	for(;x;x-=x&-x)ans+=c1[x];
	return ans;
}

int query2(int x){
	int ans=0;
	for(;x;x-=x&-x)ans+=c2[x];
	return ans;
}

void Work(){
	REP(i,1,n){
		if(!opt[i]){
			int r=lower_bound(B+1,B+cnt+1,R[i])-B;
			int l=lower_bound(B+1,B+cnt+1,L[i])-B;
			printf("%d\n",query2(r)-query1(l-1));
			add1(l,1);add2(r,1);
		}
		else{
			int r=lower_bound(B+1,B+cnt+1,R[i])-B;
			int l=lower_bound(B+1,B+cnt+1,L[i])-B;
			add1(l,-1);add2(r,-1);
		}
	}
}

void Init(){
	read(n);
	tot=cnt=0;
	REP(i,1,n){
		read(opt[i],A[i]);
		if(!opt[i]){
			pos[++tot]=i;
			L[i]=A[i];R[i]=A[i]+tot;
			B[++cnt]=A[i];B[++cnt]=A[i]+tot;
		}
		else{
			L[i]=L[pos[A[i]]];
			R[i]=R[pos[A[i]]];
		}
	}
	sort(B+1,B+cnt+1);
	REP(i,1,cnt)c1[i]=c2[i]=0;
}

int main(){
	Init();
	Work();
	return 0;
}

