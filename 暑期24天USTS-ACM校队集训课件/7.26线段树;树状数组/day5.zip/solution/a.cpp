#include<bits/stdc++.h>


using namespace std;

const int maxn = 1000010;

int n;

char A[maxn];

struct Seg{
    int l,r;
}T[maxn<<2];

struct Node{
    int l,r,ans;
}N[maxn<<2];

Node merge(Node l,Node r){
    Node tmp;
    tmp.ans=l.ans+r.ans+min(l.l,r.r);
    tmp.l=l.l+r.l-min(l.l,r.r);
    tmp.r=l.r+r.r-min(l.l,r.r);
    return tmp;
}

void build(int i,int l,int r){
    T[i].l=l;T[i].r=r;
    if(l==r){
        if(A[l]=='(')N[i].l=1;else N[i].r=1;
        return;
    }
    int M=l+r>>1;
    build(i<<1,l,M);build(i<<1|1,M+1,r);
    N[i]=merge(N[i<<1],N[i<<1|1]);
}

Node query(int i,int l,int r){
    if(l<=T[i].l&&T[i].r<=r)return N[i];
    int M=T[i].l+T[i].r>>1;
    if(r<=M)return query(i<<1,l,r);
    else if(l>M)return query(i<<1|1,l,r);
    else return merge(query(i<<1,l,r),query(i<<1|1,l,r));
}

void Work(){
    int q;
    scanf("%d",&q);
    while(q--){
        int l,r;
        scanf("%d%d",&l,&r);
        Node tmp=query(1,l,r);
        printf("%d\n",tmp.ans*2);
    }
}

void Init(){
    scanf("%s",A+1);
    n=strlen(A+1);
    build(1,1,n);
}

int main(){
    Init();
    Work();
    return 0;
}
