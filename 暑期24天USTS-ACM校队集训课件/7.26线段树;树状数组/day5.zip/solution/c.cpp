#include<bits/stdc++.h>
using namespace std;


template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}

#define LL long long 
LL mod;

int m;

struct Mar{
    LL arr[5][5];
    void in(){
        for(int i = 0 ; i < m ; i ++){
            for(int j = 0 ; j < m ; j ++){
                scanf("%lld",&arr[i][j]);
            }
        }
    }
    void out(){
        for(int i = 0 ; i < m ; i ++){
            for(int j = 0 ; j < m ; j ++){
                printf(j < m -1 ? "%lld ":"%lld\n",arr[i][j]);
            }
        }
    }
    void init(int x = 0){
        memset(arr,0,sizeof(arr));
        for(int i = 0 ; i < m ; i ++){
            arr[i][i] = x;
        }
    }
};

Mar operator * (Mar const & L, Mar const & R){
    Mar ret;
    ret.init();
    for(int i = 0 ; i < m ; i ++){
        for(int k = 0 ; k < m ; k ++){
            for(int j = 0 ; j < m ; j ++){
                ret.arr[i][j] += L.arr[i][k] * R.arr[k][j];
            }
        }
    }
    for(int i = 0 ; i < m ; i ++){
        for(int j = 0 ; j < m ; j ++){
            ret.arr[i][j] %= mod; 
        }
    }
    return ret;
}

const int maxn = 1123456;
int c[maxn];

Mar A,B;
Mar M[maxn],tail[maxn];

Mar cal(int n){
    M[0] = tail[0] = A;
    Mar pi;
    pi.init(1);

    int beg = 0;
    for(int i = 1 ; i <= n ; i ++){
        if(c[i] > beg){
            tail[i-1] = M[i-1];
            for(int j = i - 2 ; j >= c[i] ; j --){
                tail[j] = M[j] * tail[j+1];
            }
            beg = i-1;
            pi.init(1);
        }
        M[i] = tail[c[i]] * pi * B;
        pi = pi * M[i];
    }
    return M[n];
}

int main(){
    int n;
    scanf("%d %d %lld",&n,&m,&mod);
    {
        A.in(),B.in();
        for(int i = 1 ; i <= n ; i ++)
            read(c[i]);
        cal(n).out();
    }
    return 0;
}
