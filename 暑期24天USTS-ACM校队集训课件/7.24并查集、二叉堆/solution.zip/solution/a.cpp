#include"bits/stdc++.h"


#define PB push_back
#define PF push_front
#define LB lower_bound
#define UB upper_bound
#define fr(x) freopen(x,"r",stdin)
#define fw(x) freopen(x,"w",stdout)
#define iout(x) printf("%d\n",x)
#define lout(x) printf("%lld\n",x)
#define REP(x,l,u) for(int x = (l);x<=(u);x++)
#define RREP(x,l,u) for(int x = (l);x>=(u);x--)
#define mst(x,a) memset(x,a,sizeof(x))
#define PII pair<int,int>
#define PLL pair<ll,ll>
#define MP make_pair
#define se second
#define fi first
#define dbg(x) cout<<#x<<" = "<<(x)<<endl;
#define sz(x) ((int)x.size())

typedef  long long ll;
typedef unsigned long long ull;
typedef double db;
typedef long double ld;
using namespace std;

const int maxn = 1000010;
const int mod = 1e9+7;
const double eps = 1e-6;
const double PI = acos(-1);

template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}
template<typename A,typename B> inline A fexp(A x,B p){A ans=1;for(;p;p>>=1,x=1LL*x*x%mod)if(p&1)ans=1LL*ans*x%mod;return ans;}
template<typename A,typename B> inline A fexp(A x,B p,A mo){A ans=1;for(;p;p>>=1,x=1LL*x*x%mo)if(p&1)ans=1LL*ans*x%mo;return ans;}

int n,m,k;

int A[maxn],B[maxn],id[maxn],Is[maxn];

priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >Q1,Q2,Q3;

int cmp(int x,int y){
	if(B[x]!=B[y])return B[x]<B[y];
	return A[x]<A[y];
}

void Work(){
	int now=0;
	REP(i,1,k){
		now+=B[id[i]];
		if(now>m){
			iout(i-1);
			return;
		}
	}
	int ans=k;
	REP(i,1,k)Q1.push(MP(A[id[i]]-B[id[i]],i));
	REP(i,1,k)Is[id[i]]=1;
	REP(i,1,n)if(!Is[i])Q2.push(MP(A[i],i)),Q3.push(MP(B[i],i));
	while(!Q2.empty()&&!Q3.empty()){
		while(!Q2.empty()&&Is[Q2.top().se])Q2.pop();
		while(!Q3.empty()&&Is[Q3.top().se])Q3.pop();
		int t=m+1,pos=-1;
		if(!Q2.empty()&&Q2.top().fi<t)t=Q2.top().fi,pos=2;
		if(!Q3.empty()&&Q1.top().fi+Q3.top().fi<t)t=Q1.top().fi+Q3.top().fi,pos=3;
		if(pos==-1||now+t>m)break;
		now+=t;ans++;
		if(pos==2){
			Is[Q2.top().se]=1;//fi
			Q2.pop();
		}
		else{
			int x=Q3.top().se;
			Is[x]=1;
			Q1.pop();
			Q1.push(MP(A[x]-B[x],x));
			Q3.pop();
		}
	}
	iout(ans);
}

void Init(){
	read(n,k,m);
	REP(i,1,n)read(A[i]);
	REP(i,1,n)read(B[i]);
	REP(i,1,n)id[i]=i;
	sort(id+1,id+n+1,cmp);
}

int main(){
	Init();
	Work();
	return 0;
}

