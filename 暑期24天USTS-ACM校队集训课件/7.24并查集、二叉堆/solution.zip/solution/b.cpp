#include<bits/stdc++.h>
#define maxn 500100
using namespace std;
typedef long long ll;
struct Data{
	ll sz,ans,id;
	double sum;
	ll sum0,sum1;
	Data(){}
	Data(ll sz,ll sum,ll sum0,ll sum1,ll ans,ll id):sz(sz),sum(sum),sum0(sum0),sum1(sum1),ans(ans),id(id){}
	bool operator<(const Data& d)const{return sum>d.sum;}
}d[maxn];
vector<int>G[maxn];
int n,fa[maxn],f[maxn],a[maxn],val[maxn],id[maxn];
priority_queue<Data>Q;
int find(int x){return x==f[x]?x:f[x]=find(f[x]);}
void dfs(int u){
	for(auto p:G[u])if(p!=fa[u])
		fa[p]=u,dfs(p);
}
int main(){
	scanf("%d",&n);
	for(int i=0;i<=n;++i)f[i]=i;
	for(int i=2;i<=n;++i){
		scanf("%d",&a[i]);
		f[find(i)]=find(a[i]),G[a[i]].push_back(i);
	}
	G[0].push_back(1);
	fa[0]=-1,dfs(0);
	for(int i=0;i<=n;++i)f[i]=i;
	for(int i=1;i<=n;++i)scanf("%d",&val[i]),id[i]=i;
	sort(id,id+n+1,[](int a,int b){return val[a]<val[b];});
	for(int i=0;i<=n;++i){
		d[id[i]]=Data(1,val[id[i]],val[id[i]]==0,val[id[i]]==1,0,id[i]);
		if(id[i])Q.push(d[id[i]]);
	}
	ll ans=0;
	while(Q.size()){
		Data nw=Q.top();
		Q.pop();
		if(d[nw.id].sz!=nw.sz)continue;
		int x=nw.id;//cout<<x<<' ';
		x=f[x]=find(fa[x]);//cout<<x<<endl;
		ans+=(ll)nw.sum0*d[x].sum1;
		d[x].sz+=nw.sz;
		d[x].sum0+=nw.sum0;
		d[x].sum1+=nw.sum1;
		d[x].sum=(double)d[x].sum1/d[x].sz;
		if(x!=0)Q.push(d[x]);
	}
	cout<<ans<<endl;
	return 0;
}