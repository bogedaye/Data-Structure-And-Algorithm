#include<bits/stdc++.h>

#define maxn 100010

using namespace std;

int n;

long long k;

int A[maxn],mn=1000000001,mx=0;

double B[maxn],C[maxn];

long long Ans;

void solve(int l,int r){
	if(l==r)return;
	int M=l+r>>1;
	solve(l,M);solve(M+1,r);
	int nl=l,nr=M+1,cnt=0;
	for(int i=l;i<=r;i++){
		if(nl<=M&&(nr>r||B[nl]<=B[nr]))Ans+=nr-M-1,C[++cnt]=B[nl++];
		else C[++cnt]=B[nr++];
	}
	for(int i=1;i<=cnt;i++)B[l+i-1]=C[i];
}

inline void check(double M){
	B[0]=0;
	for(register int i=1;i<=n;++i)B[i]=A[i]-M+B[i-1];
	Ans=0;
	solve(0,n);
}

void Work(){
	double l=mn,r=mx;
	while(r-l>1e-5){
		double M=l/2+r/2;//cout<<l<<' '<<r<<' '<<r-l<<' '<<M-l<<' '<<r-M<<endl;
		check(M);
		if(Ans>=k)r=M;else l=M;
	}
	printf("%.4lf\n",(l+r)/2);
}

void Init(){
	cin>>n>>k;
	for(int i=1;i<=n;i++)scanf("%d",&A[i]),mn=min(mn,A[i]),mx=max(mx,A[i]);
}

int main(){
	Init();
	Work();
	return 0;
}
