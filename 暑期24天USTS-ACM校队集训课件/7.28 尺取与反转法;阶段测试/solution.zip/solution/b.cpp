#include<bits/stdc++.h>

#define ll long long

using namespace std;

int read(){
	int x=0;char ch;int f=1;
	do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');
	do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');
	return x*f;
}

const int maxn = 250010;

int n,bot;

int P[maxn],X[maxn],Y[maxn];ll R[maxn];

struct Node{
	int x,y,p,m;
	ll d,r;
	bool operator<(const Node &t)const{return d<t.d||(d==t.d&&m<t.m);}
}Q[maxn];

struct Node2{
	int l,r,mn;
}T[maxn<<2];

void pushup(int i){
	T[i].mn=min(T[i<<1].mn,T[i<<1|1].mn);
}

void build(int i,int l,int r){
	T[i].l=l;T[i].r=r;
	if(l==r){
		T[i].mn=Q[l].m;
		return;
	}
	int M=l+r>>1;
	build(i<<1,l,M);build(i<<1|1,M+1,r);
	pushup(i);
}

void update(int i,int l,int r,int p){
	if(l>r)return;
	if(T[i].l==T[i].r){
		if(T[i].mn>p)return;
		T[i].mn=1e9+10;
		bot++;R[bot]=Q[T[i].l].r;P[bot]=Q[T[i].l].p;
		return;
	}
	int M=T[i].l+T[i].r>>1;
	if(l<=M&&T[i<<1].mn<=p)update(i<<1,l,r,p);
	if(r>M&&T[i<<1|1].mn<=p)update(i<<1|1,l,r,p);
	pushup(i);
}

void Work(){
	for(int top=1;top<=bot;top++){
		Node tmp;
		tmp.d=R[top];tmp.m=1e9+10;
//		cout<<lower_bound(Q+1,Q+n+1,tmp)-Q-1<<endl;
		update(1,1,lower_bound(Q+1,Q+n+1,tmp)-Q-1,P[top]);
	}
	printf("%d\n",bot-1);
}

void Init(){
	bot=1;
	scanf("%d%d%d%lld%d",&X[bot],&Y[bot],&P[bot],&R[bot],&n);R[bot]*=R[bot];
	for(int i=1;i<=n;i++){
		Q[i].x=read();Q[i].y=read();Q[i].m=read();Q[i].p=read();Q[i].r=read();Q[i].r*=Q[i].r;
		Q[i].d=1LL*(Q[i].x-X[1])*(Q[i].x-X[1])+1LL*(Q[i].y-Y[1])*(Q[i].y-Y[1]);
	}
	sort(Q+1,Q+n+1);
	build(1,1,n);
}

int main(){
	Init();
	Work();
	return 0;
}
