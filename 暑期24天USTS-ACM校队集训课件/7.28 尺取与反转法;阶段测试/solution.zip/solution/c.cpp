#include <bits/stdc++.h>

using namespace std;

#define X first
#define Y second
#define mp make_pair
#define pb push_back
#define Debug(...) fprintf(stderr, __VA_ARGS__)

typedef long long LL;
typedef long double LD;
typedef unsigned int uint;
typedef pair<int, int> pii;
typedef unsigned long long uLL;

template <typename T>
inline void Read(T &x) {
    char c = getchar();
    bool f = false;
    for (x = 0; !isdigit(c); c = getchar()) {
        if (c == '-') {
            f = true;
        }
    }
    for (; isdigit(c); c = getchar()) {
        x = x * 10 + c - '0';
    }
    if (f) {
        x = -x;
    }
}

template <typename T>
inline bool CheckMax(T &a, const T &b) {
    return a < b ? a = b, true : false;
}

template <typename T>
inline bool CheckMin(T &a, const T &b) {
    return a > b ? a = b, true : false;
}

const int N = 500005;

struct Node {
    int s, i;
    LL v;
    
    bool operator<(const Node &b) const { return v * b.s > b.v * s; }
} b[N];

priority_queue<Node> q;

int n, a[N], f[N], vis[N];
LL ans;

inline int F(int x) {
    while (x != f[x]) {
        x = f[x] = f[f[x]];
    }
    return x;
}

inline bool Check() {
    for (int i = 1; i <= n; ++i) {
        if (!vis[i]) {
            vis[i] = i;
            for (int j = a[i]; j; j = a[j]) {
                if (vis[j] == i) {
                    return false;
                }
                if (vis[j]) {
                    break;
                }
                vis[j] = i;
            }
        }
    }
    return true;
}

int main() {
    Read(n);
    for (int i = 1; i <= n; ++i) {
        Read(a[i]), f[i] = i;
    }
    if (!Check()) {
        puts("-1");
        return 0;
    }
    b[0].s = 1;
    for (int i = 1; i <= n; ++i) {
        b[i].i = i, b[i].s = 1, Read(b[i].v), q.push(b[i]);
    }
    while (!q.empty()) {
        Node t = q.top();
        q.pop();
        if (t.s != b[t.i].s) {
            continue;
        }
        int p = F(a[t.i]);
        ans += t.v * b[p].s, f[t.i] = p, b[p].s += b[t.i].s, b[p].v += b[t.i].v;
        if (p) {
            q.push(b[p]);
        }
    }
    printf("%lld\n", ans);
    return 0;
}
