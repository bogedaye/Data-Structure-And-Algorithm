#include<bits/stdc++.h>

#define maxn 100010

using namespace std;

int n,m,Q;

int LO[maxn],RO[maxn];
int L[maxn][20],R[maxn][20];

int mx[maxn<<2];

struct Node{
	int l,r,mx;
}T[maxn*40];
int rt[maxn],sz;

//// 一棵维护原始序列的线段树
void build(int i,int l,int r){int M=l+r>>1;
	if(l==r){scanf("%d",&mx[i]);return;}
	build(i<<1,l,M);build(i<<1|1,M+1,r);
	mx[i]=max(mx[i<<1],mx[i<<1|1]);
}

void update(int i,int l,int r,int x,int V){int M=l+r>>1;
	if(l==r){mx[i]=V;return;}
	if(x<=M)update(i<<1,l,M,x,V);else update(i<<1|1,M+1,r,x,V);
	mx[i]=max(mx[i<<1],mx[i<<1|1]);
}

int query(int i,int L,int R,int l,int r){int M=L+R>>1,ans=0;
	if(l<=L&&r>=R)return mx[i];
	if(l<=M)ans=max(ans,query(i<<1,L,M,l,r));if(r>M)ans=max(ans,query(i<<1|1,M+1,R,l,r));
	return ans;
}
//////线段树

///////主席树部分
int query(int x,int l,int r,int V){int M=l+r>>1,ans=0;
	ans=max(ans,T[x].mx);
	if(l==r)return ans;
	if(V<=M)ans=max(ans,query(T[x].l,l,M,V));if(V>M)ans=max(ans,query(T[x].r,M+1,r,V));
	return ans;
}

void update(int& x,int L,int R,int l,int r,int V){int M=L+R>>1;
	T[++sz]=T[x];x=sz;
	if(l<=L&&r>=R){
		T[x].mx=V;return;
	}
	if(l<=M)update(T[x].l,L,M,l,r,V);if(r>M)update(T[x].r,M+1,R,l,r,V);
}
///////主席树部分

void Work(){
	while(Q--){int opt,V;
		scanf("%d",&opt);
		if(opt==1){int u;
			scanf("%d%d",&u,&V);
			update(1,1,n,u,V);; // 修改维护原数组的线段树
		}else{int l,r,t;
			scanf("%d%d%d",&l,&r,&V);
			t=query(rt[r],1,n,V);//查询最近的一个包含 V 位置的操作
			if(t>=l){int ll,rr;
				ll=t;for(int i=16;i>=0;i--)if(L[ll][i]>=l)ll=L[ll][i]; //倍增左端点
				rr=t;for(int i=16;i>=0;i--)if(R[rr][i]>=l)rr=R[rr][i]; //倍增右端点
				l=LO[ll];r=RO[rr];
			}else l=r=V;
//			cout<<l<<' '<<r<<endl;
			printf("%d\n",query(1,1,n,l,r)); // 查询原数组
		}
	}
}

void Init(){
	scanf("%d%d%d",&n,&m,&Q);
	build(1,1,n);
	for(int i=1;i<=m;i++){int V,j;
		scanf("%d%d",&LO[i],&RO[i]);
		V=query(rt[i-1],1,n,LO[i]); // 查询上一个包含这个操作的左端点的操作
		for(L[i][j=0]=V;j<17;j++)L[i][j+1]=L[L[i][j]][j]; // 构建倍增
		V=query(rt[i-1],1,n,RO[i]); // 查询上一个包含这个操作的右端点
		for(R[i][j=0]=V;j<17;j++)R[i][j+1]=R[R[i][j]][j]; // 构建倍增
		rt[i]=rt[i-1];update(rt[i],1,n,LO[i],RO[i],i); //主席树构建
	}
}

int main(){
	Init();
	Work();
	return 0;
}
