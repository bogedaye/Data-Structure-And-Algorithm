#include<bits/stdc++.h>



using namespace std;
const int maxn = 200010;

int n;

int pos[maxn],A[maxn],f[maxn],Ans[maxn];

int solve(int x){
	int ans=1;
	f[x]=1;
	if(x*2<=n)f[x]+=max(f[x*2],0);
	if(x*2+1<=n)f[x]+=max(f[x*2+1],0);
    ans = max(ans,f[x]);
	while(x!=1){
		int y=x>>1;
		f[y]=A[y];
		f[y]+=max(f[y<<1],0);
		f[y]+=max(f[y<<1|1],0);
		x=y;
        ans = max(ans,f[x]);
	}
	return ans;
}

void Work(){
	for(int i=0;i<n;i++)Ans[i]=0;
	for(int i=n;i;i--){
		A[pos[i]]=1;
		int x=solve(pos[i]);
		Ans[x-1]=max(Ans[x-1],i);
	}
	for(int i=n-2;i>=0;i--)Ans[i]=max(Ans[i],Ans[i+1]);
	for(int i=0;i<n;i++)printf("%d ",Ans[i]);printf("\n");
}

void Init(){
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&x);
		pos[x]=i;
	}
	for(int i=1;i<=n;i++)A[i]=f[i]=-1;
}

int main(){
	while(scanf("%d",&n)==1)
		Init(),
		Work();
	return 0;
}
