#include <set>
#include <cstdio>
#include <algorithm>

#define foredge(d) for (int j = eq[d], k; k = ee[j].to, j; j = ee[j].nx)
#define md ((lt + rt) >> 1)

using namespace std;

const int N = 200020;

typedef int arr32[N];
typedef int drr32[N << 2];

int n, m, td, dn;
arr32 val, fa, sz, tof, at, ds, rt, st, ed, v, ex;
drr32 l, r, pre, suf, sum, bst;

multiset<int> ans;

struct edge {
        int to, nx;
} ee[N << 1];
int eq[N], en = 1;

void link(int u, int v) {
        ee[++en] = (edge){v, eq[u]}, eq[u] = en;
}
void dfs1(int d, int p) {
        sz[d] = 1;
        foredge(d)
                if (k != p) {
                        fa[k] = d;
                        dfs1(k, d);
                        sz[d] += sz[k];
                }
}
void dfs2(int d, int p) {
        ds[++td] = d;
        at[d] = td;
        v[td] = val[d];

        int o = 0;
        foredge(d)
                if (k != p && sz[k] > sz[o]) {
                        o = k;
                }
        if (!o) return;
     
        tof[o] = tof[d];
        dfs2(o, d);

        foredge(d)
                if (k != p && k != o) {
                        tof[k] = k;
                        dfs2(k, d);
                }
}
void update(int d) {
        bst[d] = max(max(bst[l[d]], bst[r[d]]), suf[l[d]] + pre[r[d]]);
        sum[d] = sum[l[d]] + sum[r[d]];
        pre[d] = max(pre[l[d]], sum[l[d]] + pre[r[d]]);
        suf[d] = max(suf[r[d]], sum[r[d]] + suf[l[d]]);
}
int build(int lt, int rt) {
        int nd = ++dn;
        if (lt == rt)  {
                sum[nd] = v[lt] + ex[lt];
                bst[nd] = pre[nd] = suf[nd] = max(sum[nd], 0);
                return nd;
        }
        l[nd] = build(lt, md);
        r[nd] = build(md + 1, rt);
        return update(nd), nd;
}
void find(int d, int lt, int rt, int w) {
        if (lt == rt)  {
                sum[d] = v[lt] + ex[lt];
                bst[d] = pre[d] = suf[d] = max(sum[d], 0);
                return;
        }
        if (w <= md)  find(l[d], lt, md, w);
        else  find(r[d], md + 1, rt, w);
        update(d);
}
void upgo(int x) {
        ans.erase(ans.find(bst[rt[x]]));
        find(rt[x], st[x], ed[x], x);
        ans.insert(bst[rt[x]]);
}
int main() {
        scanf("%d %d", &n, &m);
        for (int i = 1; i <= n; i ++)  scanf("%d", val + i);
        for (int i = 2; i <= n; i ++) {
                int u, v;
                scanf("%d %d", &u, &v);
                link(u, v), link(v, u);
        }
        dfs1(1, 0);
        tof[1] = 1;
        dfs2(1, 0);
        for (int i = n, j; i >= 1; i = j - 1) {
                for (j = i; j > 1 && tof[ds[j - 1]] == tof[ds[j]]; j --);
                int nrt = build(j, i);
                ans.insert(bst[nrt]);
                for (int l = j; l <= i; l ++) {
                        rt[l] = nrt;
                        st[l] = j;
                        ed[l] = i;
                }
                ex[at[ fa[tof[ds[j]]] ]] += pre[nrt];
        }
        printf("%d\n", *ans.rbegin());
        for (int nd, nv; m --; ) {
                scanf("%d %d", &nd, &nv);
                int x = at[nd];
                for (v[x] = nv; ; ) {
                        int old = pre[rt[x]];
                        upgo(x);
                        int y = at[ fa[tof[ds[x]]] ];
                        if (!y)  break;
                        ex[y] += pre[rt[x]] - old;
                        x = y;
                }
                printf("%d\n", *ans.rbegin());
        }
}
