#include<bits/stdc++.h>

#define maxn 100010
#define pii pair<int,int>
#define MAX 0x7f7f7f7f

using namespace std;

int n,k,rt;

long long now,Ans;

int P[maxn][11],num[maxn];

struct Node{
	long long Val,lstV;
	int rt,lst;
	bool operator<(const Node &t)const{return Val>t.Val;}
	Node(long long Val=0,int rt=0,int lst=0,long long lstV=0):Val(Val),rt(rt),lst(lst),lstV(lstV) {}
};

priority_queue<Node> Q;

int mn[maxn*80],Id[maxn*80],ls[maxn*80],rs[maxn*80],sz;

void update(int x,int &y,int l,int r,int k,int V,int id){
	y=++sz;ls[y]=ls[x];rs[y]=rs[x];
	if(l==r){
		mn[y]=V;Id[y]=id;return;
	}
	int M=l+r>>1;
	if(k<=M)update(ls[x],ls[y],l,M,k,V,id);else update(rs[x],rs[y],M+1,r,k,V,id);
	mn[y]=min(mn[ls[y]],mn[rs[y]]);
}

pii query(int x,int l,int r){
	if(l==r)return make_pair(l,Id[x]);
	int M=l+r>>1;
	if(mn[ls[x]]==mn[x])return query(ls[x],l,M);else return query(rs[x],M+1,r);
}

void Work(){
	for(int i=1;i<=n;i++){
		now+=P[i][1];
		update(rt,rt,1,n,i,P[i][2]-P[i][1],1);
	}
	Q.push(Node(now,rt,0,0));
	while(k--){
		long long ans=Q.top().Val;
		int rt=Q.top().rt,lst=Q.top().lst,nr,lstV=Q.top().lstV;
		Q.pop();
		Ans+=ans;//cout<<ans<<endl;
		
		if(lst){
			update(rt,nr,1,n,lst,MAX,num[lst]);
			pii tmp=query(nr,1,n);
			int x,y;
			x=tmp.first,y=tmp.second;
			update(nr,nr,1,n,x,P[x][y+2]-P[x][y+1],y+1);
			Q.push(Node(ans-lstV+P[x][y+1]-P[x][y],nr,x,P[x][y+1]-P[x][y]));
		}
		
		pii tmp=query(rt,1,n);
		int x=tmp.first,y=tmp.second;
		update(rt,rt,1,n,x,P[x][y+2]-P[x][y+1],y+1);
		Q.push(Node(ans+P[x][y+1]-P[x][y],rt,x,P[x][y+1]-P[x][y]));
		
/*		pii tmp=query(rt,1,n);
		int x,y,nx,ny;
		x=tmp.first,y=tmp.second;
		update(rt,rt,1,n,x,MAX,num[x]);
		tmp=query(rt,1,n);
		nx=tmp.first,ny=tmp.second;
		Q.push(Node(ans-(P[x][y+1]-P[x][y])+(P[nx][ny+1]-P[nx][ny]),rt));
		update(rt,rt,1,n,x,P[x][y+2]-P[x][y+1],y+1);
	Q.push(Node(ans+P[x][y+1]-P[x][y],rt));*/
	}
	cout<<Ans<<endl;
}

void Init(){
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&num[i]);
		for(int j=1;j<=num[i];j++)scanf("%d",&P[i][j]);
		sort(P[i]+1,P[i]+num[i]+1);
		P[i][num[i]+1]=MAX;
	}
	mn[0]=MAX;
}

int main(){
	Init();
	Work();
	return 0;
}
